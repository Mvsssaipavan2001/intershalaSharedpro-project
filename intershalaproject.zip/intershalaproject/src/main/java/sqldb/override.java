package sqldb;

public @interface override {

}
