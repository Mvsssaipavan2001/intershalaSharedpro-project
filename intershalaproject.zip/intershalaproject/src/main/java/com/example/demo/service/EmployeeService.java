package com.example.demo.service;

import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Employee;
import com.example.demo.model.Professormodel;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.ProfessorRepository;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.*;
import java.util.*;

@Service
public class EmployeeService {

	private EmployeeRepository employeeRepository;
	private ProfessorRepository professorRepository;
	private DepartmentRepository departmentRepository;

	public EmployeeService(EmployeeRepository employeeRepository, ProfessorRepository professorRepository,
			DepartmentRepository departmentRepository) {
		this.employeeRepository = employeeRepository;
		this.professorRepository = professorRepository;
		this.departmentRepository = departmentRepository;
	}

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteEmployeeById(Employee employeemodel) {
		// TODO Auto-generated method stub
		employeeRepository.delete(employeemodel);
	}

	public void updateEmployee(Employee employeemodel) {
		employeeRepository.save(employeemodel);
		// TODO Auto-generated method stub
	}
	
	public void saveEmployee( Employee employeemodel) {
		employeeRepository.save(employeemodel);
		// TODO Auto-generated method stub
	}


	public void editEmployees(Employee employeemodel) {
		// TODO Auto-generated method stub
		employeeRepository.save(employeemodel);
	}

}