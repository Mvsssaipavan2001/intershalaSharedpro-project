package com.example.demo.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Departmentmodel;
import com.example.demo.model.Employee;
import com.example.demo.service.DepartmentService;
import com.example.demo.service.EmployeeService;


@RestController
@RequestMapping("/")
// @ResponseBody
public class EmployeeController {

    private EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService){
        this.employeeService = employeeService;
    }
  
    @GetMapping("/admin/getEmployee")
    public List<Employee> getEmployees(){
        return employeeService.getAllEmployees();
    }
    
    @PostMapping("/admin/editEmployee")
    public void editEmployees(@RequestBody Employee employeemodel){
    	employeeService.editEmployees(employeemodel);
    }
    
    
    @PostMapping("/admin/saveEmployee")
    public void saveEmployees(@RequestBody Employee empployeemodel){
        employeeService.saveEmployee(empployeemodel);
    }
    
    @PostMapping("/admin/deleteEmployee")
    public void deleteEmployee(@RequestBody Employee employeemodel){
        employeeService.deleteEmployeeById(employeemodel);
    }
}