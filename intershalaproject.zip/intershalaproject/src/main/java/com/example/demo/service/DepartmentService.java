package com.example.demo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Departmentmodel;
import com.example.demo.repository.DepartmentRepository;

@Service	
public class DepartmentService {    

    private DepartmentRepository departmentRepository;


    public DepartmentService(DepartmentRepository departmentRepository){
		this.departmentRepository = departmentRepository;
    }
    
    public List<Departmentmodel> getDepartments(){
    	return departmentRepository.findAll();
    }
    
    public void saveDepartments(Departmentmodel departmentModel){
    	departmentRepository.save(departmentModel);
    }
    
    public void editDepartments(Departmentmodel departmentModel){
    	departmentRepository.save(departmentModel);
    }
    
    public void deleteDepartment(Departmentmodel departmentModel){
    	 departmentRepository.delete(departmentModel);
    }

}