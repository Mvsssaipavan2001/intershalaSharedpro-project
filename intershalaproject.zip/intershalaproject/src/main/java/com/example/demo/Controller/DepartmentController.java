package com.example.demo.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Departmentmodel;
import com.example.demo.service.DepartmentService;


@RestController
@RequestMapping("/")
// @ResponseBody
public class DepartmentController {

    private DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService){
        this.departmentService = departmentService;
    }
  
    @GetMapping("/admin/getDepartments")
    public List<Departmentmodel> getDepartments(){
        return departmentService.getDepartments();
    }
    
    @PostMapping("/admin/editDepartments")
    public void editDepartments(@RequestBody Departmentmodel departmentmodel){
        departmentService.editDepartments(departmentmodel);
    }
    
    
    @PostMapping("/admin/saveDepartments")
    public void saveDepartments(@RequestBody Departmentmodel departmentmodel){
        departmentService.saveDepartments(departmentmodel);
    }
    
    @PostMapping("/admin/deleteDepartments")
    public void deleteDepartments(@RequestBody Departmentmodel departmentmodel){
        departmentService.deleteDepartment(departmentmodel);
    }
}