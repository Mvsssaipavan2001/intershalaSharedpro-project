
package com.example.demo.repository;


import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Departmentmodel;
import com.example.demo.model.Professormodel;

import org.springframework.http.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.*;
import org.springframework.beans.factory.annotation.*;
import java.util.*;

@Repository
public interface DepartmentRepository extends JpaRepository<Departmentmodel,Long> {

    List<Departmentmodel> findAll(); 
//   Departmentmodel findProfessorById(String id);
//    List<Departmentmodel> deleteProfessorById(String id);
//    Departmentmodel findByName(String name);
}


