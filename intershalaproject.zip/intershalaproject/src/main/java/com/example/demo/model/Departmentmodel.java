package com.example.demo.model;


import java.lang.annotation.Inherited;

import javax.annotation.processing.Generated;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;


@Entity
@Table(name = "Department")
public class Departmentmodel{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String DepartmentId;
    private int DepartmentPhonenumber;
    private String DepartmentHead;
    private String DepartmentBlock;
    private String DepartmentName;
   
    public String getDepartmentId() {
        return DepartmentId;
    }
    public void setDepartmentId(String DepartmentId) {
        this.DepartmentId = DepartmentId;
    }
    public int getDepartmentPhonenumber() {
        return DepartmentPhonenumber;
    }
    public void setDepartmentPhonenumber(int DepartmentPhonenumber) {
        this.DepartmentPhonenumber = DepartmentPhonenumber;
    }
    public String getDepartmentHead() {
        return DepartmentHead;
    }
    public void setDepartmentHead(String DepartmentHead) {
        this.DepartmentHead = DepartmentHead;
    }
    public String getDepartmentBlock() {
        return DepartmentBlock;
    } 
    public void setDepartmentBlock(String DepartmentBlock) {
        this.DepartmentBlock = DepartmentBlock;
    }

    public String getDepartmentName() {
        return DepartmentName;
    }
    public void setDepartmentName(String DepartmentName) {
        this.DepartmentName = DepartmentName;
    }

    public Departmentmodel(String DepartmentId, int DepartmentPhonenumber, String DepartmentHead, String DepartmentBlock,String DepartmentName) {
        this.DepartmentId = DepartmentId;
        this.DepartmentPhonenumber = DepartmentPhonenumber;
        this.DepartmentHead = DepartmentHead;
        this.DepartmentBlock = DepartmentBlock;
        this.DepartmentName = DepartmentName;
    }


    public Departmentmodel(){}
    
}