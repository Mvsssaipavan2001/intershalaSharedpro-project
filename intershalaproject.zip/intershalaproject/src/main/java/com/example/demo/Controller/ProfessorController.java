package com.example.demo.Controller;


import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.model.Professormodel;
import com.example.demo.service.ProfessorService;


@RestController
@RequestMapping("/")
// @ResponseBody
public class ProfessorController {

    private ProfessorService professorService;

    public ProfessorController(ProfessorService professorService){
        this.professorService = professorService;
    }
  
    @CrossOrigin
    @GetMapping("/admin")
    public List<Professormodel> getProfessorDetails(){
        System.out.println("hi i am employee");
        return professorService.getAllProfessor();
    }

    
    @GetMapping("/admin/getProfessor")
    public List<Professormodel> getProfessorById(){
        return professorService.getAllProfessor();
    }


    @PutMapping("/admin/editProfessor")
    public void editprofessorById(@RequestBody Professormodel professorModel){
      
    	professorService.saveProfessor(professorModel);
    }

    @PutMapping("/admin/saveProfessor")
    public void saveNewEmployee(@RequestBody Professormodel professorModel) {
    	professorService.saveProfessor(professorModel);
    }

    @DeleteMapping("/admin/deleteProfessor")
    public void deleteProfessorById(@RequestBody Professormodel professorModel ){
        professorService.deleteProfessorById(professorModel);
    }

}