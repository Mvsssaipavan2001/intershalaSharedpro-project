package com.example.demo.model;


import java.lang.annotation.Inherited;

import javax.annotation.processing.Generated;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;


@Entity
@Table(name = "Professor")
public class Professormodel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String professorId;
    private int experience;
    private String professorSubject;
    private String qualification;
    private String professorName;
   
    public String getProfessorId() {
        return professorId;
    }
    public void setProfessorId(String ProfessorId) {
        this.professorId = ProfessorId;
    }
    public int getexperience() {
        return experience;
    }
    public void setexperience(int experience) {
        this.experience = experience;
    }
    public String getProfessorSubject() {
        return professorSubject;
    }
    public void setProfessorSubject(String ProfessorSubject) {
        this.professorSubject = ProfessorSubject;
    }
    public String getQualification() {
        return qualification;
    } 
    public void setQualification(String Qualification) {
        this.qualification = Qualification;
    }

    public String getProfessorName() {
        return professorName;
    }
    public void setProfessorName(String ProfessorName) {
        this.professorName = ProfessorName;
    }

    public Professormodel(String ProfessorId, int experience, String ProfessorSubject, String Qualification,String ProfessorName) {
        this.professorId = ProfessorId;
        this.experience = experience;
        this.professorSubject = ProfessorSubject;
        this.qualification = Qualification;
        this.professorName = ProfessorName;
    }


    public Professormodel(){}
    
}