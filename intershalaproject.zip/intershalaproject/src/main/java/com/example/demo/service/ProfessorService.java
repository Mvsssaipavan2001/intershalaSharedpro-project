package com.example.demo.service;

import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Employee;
import com.example.demo.model.Professormodel;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.ProfessorRepository;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.*;
import java.util.*;

@Service
public class ProfessorService {

	private EmployeeRepository employeeRepository;
	private ProfessorRepository professorRepository;
	private DepartmentRepository departmentRepository;

	public ProfessorService(EmployeeRepository employeeRepository, ProfessorRepository professorRepository,
			DepartmentRepository departmentRepository) {
		this.employeeRepository = employeeRepository;
		this.professorRepository = professorRepository;
		this.departmentRepository = departmentRepository;
	}

	public List<Professormodel> getAllProfessor() {
		// TODO Auto-generated method stub
		return professorRepository.findAll();
	}

	public void deleteProfessorById(Professormodel professormodel) {
		// TODO Auto-generated method stub
		
		professorRepository.delete(professormodel);
	}

	public  void saveProfessor(Professormodel professorModel) {
		// TODO Auto-generated method stub
		professorRepository.save(professorModel);
	}

	public void updateprofessor(Professormodel professorModel) {
		// TODO Auto-generated method stub
		professorRepository.save(professorModel);
	}

}