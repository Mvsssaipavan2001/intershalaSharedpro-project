package com.example.demo.model;


import java.lang.annotation.Inherited;

import javax.annotation.processing.Generated;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;


@Entity
@Table(name = "Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String employeeId;
    private int birthdaydate;
    private String city;
    private String address;
    private String employeeName;
    private String gender;
    private String age;
    
    public String getemployeeId() {
        return employeeId;
    }
    public void setemployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    public int getbirthdaydate() {
        return birthdaydate;
    }
    public void setbirthdaydate(int birthdaydate) {
        this.birthdaydate = birthdaydate;
    }
    public String getcity() {
        return city;
    }
    public void setcity(String city) {
        this.city = city;
    }
    public String getaddress() {
        return address;
    } 
    public void setaddress(String address) {
        this.address = address;
    }

    public String getemployeeName() {
        return employeeName;
    }
    public void setemployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    public String gender() {
        return gender;
    }
    public void setgender(String gender) {
        this.gender = gender;
    }
    public String age() {
        return age;
    }
    public void age(String age) {
        this.age = age;
    }
    public Employee(String employeeId, int birthdaydate, String city, String address,String employeeName, String gender, String age) {
        this.employeeId = employeeId;
        this.birthdaydate = birthdaydate;
        this.city = city;
        this.address = address;
        this.employeeName = employeeName;
        this.gender = gender;
        this.age = age;
    }


    public Employee(){}
    
}