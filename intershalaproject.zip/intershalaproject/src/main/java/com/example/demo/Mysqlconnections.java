package com.example.demo;
import org.hibernate.mapping.Selectable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import sqldb.override;
@SpringBootApplication
public abstract class Mysqlconnections implements CommandLineRunner {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public static void main(String[] args) {
		SpringApplication.run(Mysqlconnections.class, args);
	}
	@override
	public void run(String...args) throws Exception{
		String sql = "INSERT INTO employess(Id,city,address,birthdaydate,employeeName,gender,age) values(?,?,?,?,?,?,?)";
		int result = jdbcTemplate.update(sql,"13707","chennai","avadi","08082001","pavankumar","male","21");
		if(result>0) {
			System.out.println("new employee is added");
		}
		
		String sql1 = "SELECT Professor, Employee from department_id in(?,?),ORDER BY department_id";	
		Selectable  employees;
	}}	

